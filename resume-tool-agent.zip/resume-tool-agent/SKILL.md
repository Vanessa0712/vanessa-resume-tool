---
name: resume-tool-agent
description: 驱动本地 resume-tool（简历筛选工具）完成免 API Key 的 AI 协作筛选。当用户提到「筛选简历」「跑一下简历初筛」「用简历工具筛人」「处理今天的简历」等场景时使用本技能。流程：定位本机 resume-tool → 关键词初筛 → agent-export 导出脱敏批次 → 在会话内逐份评估 → agent-import 写回结果库。全程不接触任何大模型 API Key，额度消耗记在当前登录的 WorkBuddy 账号。
agent_created: true
---

# Resume Tool Agent（简历协作筛选）

## 概述

本地 resume-tool 提供 `agent-export` / `agent-import` 两个 CLI 接口，专供 WorkBuddy Agent 驱动：工具负责存储、关键词初筛与 PII 脱敏，Agent 负责在本会话内做大模型语义评估，结果写回工具的 SQLite 库后，Web UI 与 CSV/xlsx 报告零改动即可显示。

## 触发场景

- 「帮我筛选简历」「跑一下初筛」「筛今天新进的简历」
- 「用 resume-tool 处理 QA 工程师的简历」（带模板名）
- 「把待核实的名单复核一遍」（funnel 第 2 阶段的 Agent 替代）

## 第一步：定位工具与模板

1. 确定 resume-tool 安装目录。按顺序尝试：
   - 询问用户安装路径（exe 分发场景下路径各机不同）
   - 常见位置探测：`~/WorkBuddy/*/resume-tool/`、`~/Desktop/resume-tool/`、`~/resume-tool/`
   - 验证方式：目录内存在 `resume_tool.py`（源码运行）或 exe 入口
2. 确定筛选模板。用户未指定时先列出可选模板（`config/template.json` 为默认，`config/templates/` 下可有多份），让用户选择；用户说「QA 工程师」之类的岗位词时，匹配模板名或让用户确认。

## 第二步：关键词初筛（免费、本地）

```bash
cd <resume-tool目录>
python resume_tool.py screen --engine keyword --template <模板路径>
```

输出每份简历的 `通过 / 待核实 / 未通过` 状态。若用户只要复核「待核实」名单（推荐，省额度），跳到第三步默认导出；若要全量 AI 评估，导出时加 `--all`。

若简历尚未导入，先执行 `python resume_tool.py import --dir <简历目录>`。

## 第三步：导出脱敏批次

```bash
python resume_tool.py agent-export --template <模板路径> --out agent-batch.json
# 默认只导 keyword 为「待核实」的；全量加 --all；指定 ID 加 --ids 1,3,5
```

批次 JSON 自描述，包含 `instructions`（输出格式与评分口径）、`criteria`（必备门槛/年限/核心技能权重/加分项）、`resumes[]`（已打码姓名/手机/邮箱的文本）。

## 第四步：会话内评估（本技能的核心价值）

1. 完整读取批次文件，逐份对照 `criteria` 评估，严格按 `instructions` 中约定的 JSON 格式输出：
   `{"resume_id": 整数, "passed": true/false, "score": 0-100整数, "missing": ["缺失必备项"], "reason": "50字内中文理由"}`
2. 评估纪律：
   - 只依据批次内文本证据，不臆造简历内容；证据不足宁可低分并写明原因
   - `score` 与 `passed` 保持一致（passed=true 时 score≥50）；`missing` 只列 `required_skills` 中确实无证据的项
   - 文本已脱码（姓名/手机/邮箱），正常按技能与年限表述评分，不要因打码扣分
3. 将所有结果组成一个 JSON 数组，写入 `<resume-tool目录>/agent-results.json`。
4. 批次较大时（如 20 份以上）分批处理：每批评估-写回-再导出下一批，避免上下文超限。

## 第五步：写回并汇报

```bash
python resume_tool.py agent-import --in agent-results.json --template <模板路径>
```

- 校验失败的条目会逐条提示并跳过，不影响其余写回；按提示修正后重导即可
- 完成后向用户汇报：通过/未通过数量、头部候选人（分数前几名及理由）、边缘名单（50-79 分，建议人工面审）
- 提醒用户可在 Web UI（`python app.py` → http://127.0.0.1:5000）查看报告与图表，或 `export --out report.csv` 导出

## 边界与注意

- 简历正文会进入本会话上下文：脱敏仅覆盖姓名/手机/邮箱，其余内容照常评估，不得在汇报中复述无关隐私细节
- 不得替用户编辑 `config/providers.json` 或触碰任何 API Key——本流程的全部意义就是免 Key
- `agent-import` 把结果记为 engine=ai（detail 含 provider=workbuddy-agent 溯源），这是设计行为，不要另行改库
- 用户要求「重新筛」「换个模板」时，从头执行第二步（screen 会追加新记录而非覆盖，历史可追溯）
